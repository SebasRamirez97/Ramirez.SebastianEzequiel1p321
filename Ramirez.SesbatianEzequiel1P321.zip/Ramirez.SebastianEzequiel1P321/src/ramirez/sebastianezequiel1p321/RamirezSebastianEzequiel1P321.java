package ramirez.sebastianezequiel1p321;

public class RamirezSebastianEzequiel1P321 {

    public static void main(String[] args) {
        Acuario acuario = new Acuario();

        Coral coralAzul = new Coral("Coral Azul", "T1", TipoAgua.AGUA_SALADA, 5.0);
        Pez pezPayaso = new Pez("Pez Payaso", "T1", TipoAgua.AGUA_SALADA, 15.0);
        Pez pezPayaso2 = new Pez("Pez Payaso", "T1", TipoAgua.AGUA_SALADA, 15.0);
        Pez pezCirujano = new Pez("Pez Cirujano", "T2", TipoAgua.AGUA_SALADA, 20.0);
        Molusco caracolMarino = new Molusco("Caracol Marino", "T1", TipoAgua.AGUA_SALADA, "espiralada");
        Molusco mejillon = new Molusco("Mejillón", "T3", TipoAgua.AGUA_DULCE, "bivalva");
        Coral coralRojo = new Coral("Coral Rojo", "T4", TipoAgua.AGUA_SALADA, 5.0);
        Coral coralBlanco = new Coral("Coral Blanco", "T5", TipoAgua.AGUA_DULCE, 3.0);

        acuario.agregarEspecie(coralAzul);
        acuario.agregarEspecie(pezPayaso);
        //acuario.agregarEspecie(pezPayaso2);
        acuario.agregarEspecie(pezCirujano);
        acuario.agregarEspecie(caracolMarino);
        //acuario.agregarEspecie(caracolMarino);
        acuario.agregarEspecie(mejillon);
        //acuario.agregarEspecie(mejillon);
        acuario.agregarEspecie(coralRojo);
        acuario.agregarEspecie(coralBlanco);

        // Mostrar especies
        System.out.println("\nDetalle de las especies:");
        acuario.mostrarEspecies();

        // Mover especies
        System.out.println("\nMovimiento de especies:");
        acuario.moverEspecies();

        // Realizar funciones biológicas
        System.out.println("\nFunciones biológicas:");
        acuario.realizarFuncionesBiologicas();

        // Tipo Agua
        System.out.println("\nPor tipo de agua:");
        acuario.filtrarPorTipoAgua(TipoAgua.AGUA_SALADA);
    }
}
