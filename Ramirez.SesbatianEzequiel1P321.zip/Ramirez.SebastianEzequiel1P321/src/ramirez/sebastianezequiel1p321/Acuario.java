package ramirez.sebastianezequiel1p321;

import java.util.ArrayList;
import java.util.List;

public class Acuario {

    private List<EspecieMarina> especies;

    public Acuario() {
        this.especies = new ArrayList<>();
    }

    private boolean especieRepetida(EspecieMarina especie) {
        return especies.contains(especie);
    }

    public void agregarEspecie(EspecieMarina especie) {
        if (especieRepetida(especie)) {
            throw new ErrorEspecieRepetidaException(especie.mensajeErrorRepetido());
        }
        especies.add(especie);
    }

    private void mostrarListaEspecies(List<EspecieMarina> listaEspecies) {
        if (listaEspecies.isEmpty()) {
            System.out.println("Lista de especies vacia");
        } else {
            int i = 0;
            while (i < listaEspecies.size()) {
                System.out.println(listaEspecies.get(i));
                i++;
            }
        }
    }

    public void mostrarEspecies() {
        mostrarListaEspecies(especies);
    }

    public void moverEspecies() {
        List<EspecieMarina> noMovibles = new ArrayList<>();

        for (EspecieMarina e : especies) {
            if (e.esMovible()) {
                System.out.println(e);
                ((Movible) e).mover();
                System.out.println("");
            } else {
                noMovibles.add(e);
            }
        }
        System.out.println("Las especies que no se pueden mover son: ");
        mostrarListaEspecies(noMovibles);

    }

    public void realizarFuncionesBiologicas() {
        for (EspecieMarina e : especies) {
            if (e.esAlimentable()) {
                ((Alimentable) e).alimentar();
            }
            e.reproducir();
            e.respirar();
        }

    }

    public List<EspecieMarina> filtrarPorTipoAgua(TipoAgua tipo) {
        List<EspecieMarina> deTipoAgua = new ArrayList<>();
        System.out.println("Las especies del tipo " + tipo + " son: ");
        for (EspecieMarina e : especies) {
            if (e.esDeTipo(tipo)) {
                deTipoAgua.add(e);
            }
        }
        mostrarListaEspecies(deTipoAgua);
        return deTipoAgua;
    }
}
