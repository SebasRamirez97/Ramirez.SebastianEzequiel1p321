package ramirez.sebastianezequiel1p321;

public interface Alimentable {

    public void alimentar();
}
