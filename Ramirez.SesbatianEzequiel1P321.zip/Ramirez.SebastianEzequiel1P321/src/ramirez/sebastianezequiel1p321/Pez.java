package ramirez.sebastianezequiel1p321;

public class Pez extends EspecieMarina implements Alimentable, Movible {

    private double longitudMaxima;

    public Pez(String nombre, String tanque, TipoAgua tipoAgua, double longitudMaxima) {
        super(nombre, tanque, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }

    @Override
    public void alimentar() {
        System.out.println("Alimentando pez");
    }

    @Override
    public void respirar() {
        System.out.println("Soy un pezx y respiro");
    }

    @Override
    public void reproducir() {
        System.out.println("Soy un pez y me reproduzco");
    }

    @Override
    public void mover() {
        System.out.println("Soy un pez y me muevo");
    }

    @Override
    public String toString() {
        return super.toString() + "Pez{" + "longitudMaxima=" + longitudMaxima + '}';
    }
}
