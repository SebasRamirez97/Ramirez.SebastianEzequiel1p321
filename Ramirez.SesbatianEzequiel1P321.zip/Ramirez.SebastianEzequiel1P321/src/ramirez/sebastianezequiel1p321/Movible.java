package ramirez.sebastianezequiel1p321;

public interface Movible {

    public void mover();
}
