package ramirez.sebastianezequiel1p321;

public class Coral extends EspecieMarina {

    private double profundidadIdeal;

    public Coral(String nombre, String tanque, TipoAgua tipoAgua, double profundidadIdeal) {
        super(nombre, tanque, tipoAgua);
        this.profundidadIdeal = profundidadIdeal;
    }

    @Override
    public void respirar() {
        System.out.println("Soy un coral y respiro");
    }

    @Override
    public void reproducir() {
        System.out.println("Soy un coral y me reproduzco");
    }

    public String toString() {
        return super.toString() + "Coral{" + "profundidadIdeal=" + profundidadIdeal + '}';
    }
}
