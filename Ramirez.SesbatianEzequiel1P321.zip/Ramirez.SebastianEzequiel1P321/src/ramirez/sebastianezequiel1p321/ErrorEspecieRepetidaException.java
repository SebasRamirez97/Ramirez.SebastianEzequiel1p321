package ramirez.sebastianezequiel1p321;

public class ErrorEspecieRepetidaException extends RuntimeException {

    private final static String MENSAJE = "Especie Rpetida";

    public ErrorEspecieRepetidaException() {
        super(MENSAJE);
    }

    public ErrorEspecieRepetidaException(String mensaje) {
        super(mensaje);
    }

}
