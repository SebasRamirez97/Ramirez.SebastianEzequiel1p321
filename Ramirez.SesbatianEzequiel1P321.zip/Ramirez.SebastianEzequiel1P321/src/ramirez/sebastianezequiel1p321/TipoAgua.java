package ramirez.sebastianezequiel1p321;

public enum TipoAgua {
    AGUA_SALADA,
    AGUA_DULCE
}
