package ramirez.sebastianezequiel1p321;

public class Molusco extends EspecieMarina implements Alimentable, Movible {

    private String tipoConcha;

    public Molusco(String nombre, String tanque, TipoAgua tipoAgua, String tipoConcha) {
        super(nombre, tanque, tipoAgua);
        this.tipoConcha = tipoConcha;
    }

    @Override
    public void alimentar() {
        System.out.println("Alimentando molusco");
    }

    public void respirar() {
        System.out.println("Soy un molusco y respiro");
    }

    public void reproducir() {
        System.out.println("Soy un molusco y me reproduzco");
    }

    @Override
    public void mover() {
        System.out.println("Soy un molusco y me muevo");
    }

    @Override
    public String toString() {
        return super.toString() + "Molusco{" + "tipoConcha=" + tipoConcha + '}';
    }
}
