package ramirez.sebastianezequiel1p321;

public interface FuncionBiologica {

    public void reproducir();

    public void respirar();
}
