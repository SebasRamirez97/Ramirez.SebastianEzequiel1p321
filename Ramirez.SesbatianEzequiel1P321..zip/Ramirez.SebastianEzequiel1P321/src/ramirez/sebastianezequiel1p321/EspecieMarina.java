/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.sebastianezequiel1p321;

import java.util.Objects;

public abstract class EspecieMarina implements Respirable, Reproducible{
    private String nombre;
    private String tanque;
    private Agua tipoAgua;

    public EspecieMarina(String nombre, String tanque, Agua tipoAgua) {
        this.nombre = nombre;
        this.tanque = tanque;
        this.tipoAgua = tipoAgua;
    }
    
    public boolean esMovible(){   
        return this instanceof Movible;
    }
    
    public boolean esAlimentable(){   
        return this instanceof Alimentable;
    }
    
    @Override
    public boolean equals(Object o){
       if (o == null || !(o instanceof EspecieMarina especie)) {
           return false;
       }
   
        return nombre.equals(especie.nombre) && tanque.equals(especie.tanque);
    }
    @Override
    public int hashCode(){
        return Objects.hash(nombre, tanque);
    }

    @Override
    public String toString() {
        return "EspecieMarina{" + "nombre= " + nombre + ", tanque= " + tanque + ",agua= " + tipoAgua +'}';
    }
}
