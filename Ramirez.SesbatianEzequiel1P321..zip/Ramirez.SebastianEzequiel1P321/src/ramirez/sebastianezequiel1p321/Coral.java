/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.sebastianezequiel1p321;


public class Coral extends EspecieMarina{
    private double profundidadIdeal;

    public Coral(String nombre, String tanque, Agua tipoAgua, double profundidadIdeal) {
        super(nombre, tanque, tipoAgua);
        this.profundidadIdeal = profundidadIdeal;
    }
    
    
    
    public void respirar(){
        System.out.println("Soy un coral y respiro");
    }
    public void reproducir(){
        System.out.println("Soy un coral y me reproduzco");
    }
    
    public String toString() {
        return super.toString() + "Coral{" + "profundidadIdeal=" + profundidadIdeal + '}';
    }
    
    
    
}
