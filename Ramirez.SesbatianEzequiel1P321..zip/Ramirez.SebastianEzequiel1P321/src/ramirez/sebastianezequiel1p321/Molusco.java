/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.sebastianezequiel1p321;

/**
 *
 * @author User
 */
public class Molusco extends EspecieMarina implements Alimentable, Movible{
    private String tipoConcha;

    public Molusco(String nombre, String tanque,Agua tipoAgua,String tipoConcha) {
        super(nombre, tanque, tipoAgua);
        this.tipoConcha = tipoConcha;
    }
    @Override
    public void alimentar(){
        System.out.println("Alimentando molusco");
    }
    @Override
    public void respirar(){
        System.out.println("Soy un molusco y respiro");
    }
    
    @Override
    public void reproducir(){
        System.out.println("Soy un molusco y me reproduzco");
    }
    
    @Override
    public String toString() {
        return super.toString()+"Molusco{" + "tipoConcha=" + tipoConcha + '}';
    }
    
    
    
    
   
    
    
    
}
