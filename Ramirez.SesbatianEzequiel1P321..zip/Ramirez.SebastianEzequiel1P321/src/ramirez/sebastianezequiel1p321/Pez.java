/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.sebastianezequiel1p321;

public class Pez extends EspecieMarina implements Alimentable, Movible{
    private double longitudMaxima;

    public Pez(String nombre,Agua tipoAgua, String tanque, double longitudMaxima) {
        super(nombre, tanque, tipoAgua);
        this.longitudMaxima = longitudMaxima;
    }
    
    @Override
    public void alimentar(){
        System.out.println("Alimentando pez");
    }
    
    @Override
    public void respirar(){
        System.out.println("Soy un pezx y respiro");
    }
    @Override
    public void reproducir(){
        System.out.println("Soy un pez y me reproduzco");
    }
    
    
    @Override
    public String toString() {
        return super.toString()+"Pez{" + "longitudMaxima=" + longitudMaxima + '}';
    }
    
    
}
