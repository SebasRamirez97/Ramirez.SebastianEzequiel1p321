/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ramirez.sebastianezequiel1p321;

public class RamirezSebastianEzequiel1P321 {

 
    public static void main(String[] args) {
        Acuario acuario = new Acuario();
        
        Pez pezPayaso = new Pez("Pez Payaso", Agua.AGUA_SALADA, "T1", 15.0);
        Pez pezPayaso2 = new Pez("Pez Payaso", Agua.AGUA_SALADA, "T1", 15.0);
        Pez pezCirujano = new Pez("Pez Cirujano", Agua.AGUA_SALADA, "T2", 20.0);
        Molusco caracolMarino = new Molusco("Caracol Marino", "T1", Agua.AGUA_SALADA, "espiralada");
        Molusco mejillon = new Molusco("Mejillón", "T3", Agua.AGUA_DULCE, "bivalva");
        Coral coralRojo = new Coral("Coral Rojo", "T4", Agua.AGUA_SALADA, 5.0);
        Coral coralBlanco = new Coral("Coral Blanco", "T5", Agua.AGUA_DULCE, 3.0);

        
        acuario.agregarEspecie(pezPayaso);
        acuario.agregarEspecie(pezCirujano);
        acuario.agregarEspecie(caracolMarino);
        acuario.agregarEspecie(mejillon);
        acuario.agregarEspecie(coralRojo);
        acuario.agregarEspecie(coralBlanco);

        // Mostrar especies
        acuario.mostrarEspecies();

        // Mover especies
        
        System.out.println("\n🚚 Movimiento de especies:");
        acuario.moverEspecies();

        // Realizar funciones biológicas
        System.out.println("\n🧬 Funciones biológicas:");
        acuario.realizarFuncionesBiologicas();
        
        
    }
}

    
    

