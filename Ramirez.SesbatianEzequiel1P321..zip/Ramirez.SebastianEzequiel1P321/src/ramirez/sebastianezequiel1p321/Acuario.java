/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ramirez.sebastianezequiel1p321;

import java.util.ArrayList;
import java.util.List;

public class Acuario {

    private List<EspecieMarina> especies;

    public Acuario() {
        this.especies = new ArrayList<>();
    }
    
    public boolean especieRepetida(EspecieMarina especie) {
    return especies.contains(especie);
}

    public void agregarEspecie(EspecieMarina especie) {
        if (this.especieRepetida(especie)){
            throw new ErrorEspecieRepetidaException();
        }
        especies.add(especie);
    }
    public void mostrarListaEspecies(List<EspecieMarina> listaEspecies){
        int i = 0;
        while (i < listaEspecies.size()) {
            System.out.println(listaEspecies.get(i).toString());
            i++;
        }
    }
    public void mostrarEspecies() {
        mostrarListaEspecies(especies);
    }

    public void moverEspecies() {
        List<EspecieMarina> noMovibles = new ArrayList<>();
        System.out.println("Las especies que no se pueden mover son: ");
        for (EspecieMarina e : especies) {
            if (!(e.esMovible())) {
                noMovibles.add(e);
            }
            mostrarListaEspecies(noMovibles);
     
        }
    
    }
    
    public void realizarFuncionesBiologicas(){
        for (EspecieMarina e : especies) {
            if (e.esAlimentable()) {
                ((Alimentable) e).alimentar();
            }
            e.reproducir();
            e.respirar();
        }
    } 
}
